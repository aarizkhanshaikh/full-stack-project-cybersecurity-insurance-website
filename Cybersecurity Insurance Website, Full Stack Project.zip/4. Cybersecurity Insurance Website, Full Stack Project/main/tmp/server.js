const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MongoDB connection
mongoose.connect('mongodb://localhost:27017/cybersecurity_insurance', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});
const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', function () {
    console.log('Connected to MongoDB');
});

// Define Schema and Model (example)
const SubmissionSchema = new mongoose.Schema({
    company_name: String,
    company_email: String,
    company_sector: String,
    company_size: String,
    annual_revenue: Number,
    framework: String,
    risk_level: String,
    data_sensitivity: String,
    // Define other fields as needed
});

const Submission = mongoose.model('Submission', SubmissionSchema);

// Routes
app.post('/submit-form', (req, res) => {
    const formData = req.body;

    const newSubmission = new Submission(formData);

    newSubmission.save()
        .then(result => {
            res.status(200).json(result);
        })
        .catch(err => {
            res.status(500).json({ error: err.message });
        });
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
