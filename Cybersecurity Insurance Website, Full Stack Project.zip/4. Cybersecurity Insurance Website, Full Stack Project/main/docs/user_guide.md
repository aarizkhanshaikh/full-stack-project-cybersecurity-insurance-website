# User Guide for Cybersecurity Insurance Project

## Introduction
This user guide provides instructions on how to use the Cybersecurity Insurance Project effectively. The application is designed to help companies assess their cybersecurity risks and recommend appropriate insurance coverage.

## Getting Started
1. **Accessing the Application**:
   Open your web browser and navigate to `http://localhost:3000` after starting the server.

2. **Navigating the Interface**:
   The main page features a risk assessment form that you will fill out to receive insurance recommendations.

## Filling Out the Risk Assessment Form
- **Company Name**: Enter the official name of your company.
- **Company Email**: Provide a valid email address for correspondence.
- **Company Sector**: Select the sector your company operates in from the dropdown menu.
- **Company Size**: Indicate the size of your company (e.g., small, medium, large).
- **Annual Revenue**: Input your company's annual revenue.
- **Framework**: Choose the cybersecurity framework your company follows.
- **Risk Level**: Select the perceived risk level for your company.
- **Data Sensitivity**: Specify the sensitivity level of the data your company handles (e.g., low, medium, high).

## Submitting the Form
Once you have filled in all the required fields, click the "Submit" button to send your data for processing. 

### Client-Side Validation
Before submission, the application performs client-side validation to ensure all required fields are filled and correctly formatted. If there are any issues, an error message will be displayed.

## Viewing the Results
After submission, you will be redirected to a results page that displays your recommended insurance coverage based on the information provided. 

### Error Handling
If there are any issues during the submission process, an error message will appear, prompting you to try again later.

## Conclusion
This application aims to streamline the process of assessing cybersecurity risks and recommending insurance. 