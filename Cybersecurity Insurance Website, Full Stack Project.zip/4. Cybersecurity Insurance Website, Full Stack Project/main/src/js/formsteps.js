$(document).ready(function() {
    // Go to Step 2
    $("#nextToStep2").click(function() {
        $("#step1").addClass("d-none");
        $("#step2").removeClass("d-none");
        $("#progressBar").css("width", "66%");
        $("#progressBar").text("Step 2 of 3");
    });

    // Go back to Step 1
    $("#backToStep1").click(function() {
        $("#step2").addClass("d-none");
        $("#step1").removeClass("d-none");
        $("#progressBar").css("width", "33%");
        $("#progressBar").text("Step 1 of 3");
    });

    // Go to Step 3
    $("#nextToStep3").click(function() {
        $("#step2").addClass("d-none");
        $("#step3").removeClass("d-none");
        $("#progressBar").css("width", "100%");
        $("#progressBar").text("Step 3 of 3");
    });

    // Go back to Step 2
    $("#backToStep2").click(function() {
        $("#step3").addClass("d-none");
        $("#step2").removeClass("d-none");
        $("#progressBar").css("width", "66%");
        $("#progressBar").text("Step 2 of 3");
    });
});
