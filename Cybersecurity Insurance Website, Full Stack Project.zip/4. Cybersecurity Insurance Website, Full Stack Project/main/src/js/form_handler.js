// m.js

document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('risk-assessment-form');

    form.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent the form from submitting normally

        const formData = new FormData(form);

        // Convert FormData to object
        const formDataObj = {};
        formData.forEach((value, key) => {
            formDataObj[key] = value;
        });

        // Perform client-side validation
        let isValid = validateForm(formDataObj);

        if (isValid) {
            // Make AJAX request to submit form data
            const xhr = new XMLHttpRequest();
            const url = '/submit-form';
            xhr.open('POST', url, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        // Success response handling
                        const response = JSON.parse(xhr.responseText);
                        console.log(response); // Log or handle success response
                        alert('Form submitted successfully!');
                        form.reset(); // Optionally reset the form after successful submission
                    } else {
                        // Error handling
                        alert('Error submitting form. Please try again later.');
                    }
                }
            };

            // Send JSON data as the body of the request
            xhr.send(JSON.stringify(formDataObj));
        } else {
            alert('Please fill in all required fields.');
        }
    });

    function validateForm(formData) {
        // Example: Check if required fields are filled
        const requiredFields = ['company_name', 'company_email', 'company_sector', 'company_size', 'framework', 'risk_level', 'data_sensitivity'];
        for (let field of requiredFields) {
            if (!formData[field]) {
                const inputField = document.getElementById(field);
                inputField.classList.add('error-input'); // Apply CSS for error indication
                return false;
            }
        }

        // Example: Validate email format
        const email = formData['company_email'];
        if (!isValidEmail(email)) {
            const inputField = document.getElementById('company-email');
            inputField.classList.add('error-input'); // Apply CSS for error indication
            return false;
        }

        // Additional validation checks can be added as needed

        return true;
    }

    function isValidEmail(email) {
        // Simple email validation regex
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});
